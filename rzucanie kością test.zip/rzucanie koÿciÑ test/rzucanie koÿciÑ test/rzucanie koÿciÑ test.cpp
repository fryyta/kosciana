﻿#include <iostream>
#include <cstdlib>
#include <ctime>
int main()
{
    srand( time ( NULL ) );
    int liczba =( std::rand() % 6) + 1;
    int liczba2 = (std::rand() % 6) + 1;
    std::cout << "kosc 1: " << liczba  << std::endl;
    std::cout << "kosc 2: " << liczba2 << std::endl;
    return 0;
}
