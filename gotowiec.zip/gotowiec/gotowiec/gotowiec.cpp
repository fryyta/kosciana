﻿#include<iostream>
#include<string>
#include <vector>
#include <cstdlib>
#include <ctime>

using namespace std;

class Player
{
public:
    int points = 0;
    string name;
    vector < Player > players_tab;

    void game_info()
    {
        Player p1;
        int number_of_players = 0;
        cout << "\n\nSet number of players: " << endl;
        cin >> number_of_players;
        for (int x = 1; x <= number_of_players; x++)
        {
            cout << "\n\n Enter name for player ";
            cout << x;
            cout << ": ";
            cin >> p1.name;
            players_tab.push_back(p1);
        }

    }

    void show()
    {
        cout << "Players:" << endl;
        int iterator = 1;
        for (int x = 0; x < players_tab.size(); x++)
        {
            cout << iterator << ".";
            cout << players_tab[x].name << endl;
            iterator++;
        }

    }
};
class Dice
{
public:
    void random_numbers()
    {
        int tmp_dice = (rand() % 6) + 1;
        cout << tmp_dice;
    }

};

int main()
{
    srand(time(NULL));

    Player p1;
    p1.game_info();
    p1.show();
    system("pause");

    return 0;
}